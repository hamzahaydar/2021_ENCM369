/*!*********************************************************************************************************************
@file user_app.c                                                                
@brief User's tasks / applications are written here.  This description
should be replaced by something specific to the task.

------------------------------------------------------------------------------------------------------------------------
GLOBALS
- NONE

CONSTANTS
- NONE

TYPES
- NONE

PUBLIC FUNCTIONS
- NONE

PROTECTED FUNCTIONS
- void UserApp1Initialize(void)
- void UserApp1Run(void)


**********************************************************************************************************************/

#include "configuration.h"

/***********************************************************************************************************************
Global variable definitions with scope across entire project.
All Global variable names shall start with "G_<type>UserApp1"
***********************************************************************************************************************/
/* New variables */
volatile u8 G_u8UserAppFlags;                             /*!< @brief Global state flags */


/*--------------------------------------------------------------------------------------------------------------------*/
/* Existing variables (defined in other files -- should all contain the "extern" keyword) */
extern volatile u32 G_u32SystemTime1ms;                   /*!< @brief From main.c */
extern volatile u32 G_u32SystemTime1s;                    /*!< @brief From main.c */
extern volatile u32 G_u32SystemFlags;                     /*!< @brief From main.c */


/***********************************************************************************************************************
Global variable definitions with scope limited to this local application.
Variable names shall start with "UserApp_<type>" and be declared as static.
***********************************************************************************************************************/


/**********************************************************************************************************************
Function Definitions
**********************************************************************************************************************/

/*--------------------------------------------------------------------------------------------------------------------*/
/*! @publicsection */                                                                                            
/*--------------------------------------------------------------------------------------------------------------------*/



/*--------------------------------------------------------------------------------------------------------------------*/
/*! @protectedsection */                                                                                            
/*--------------------------------------------------------------------------------------------------------------------*/


/*--------------------------------------------------------------------
    void TimeXus(INPUT_PARAMETER_)
    Sets Timer0 to count u16Microseconds_
    Requires:
    - Timer0 configured such that each timer tick is 1 microsecond
    - INPUT_PARAMETER_ is the value in microseconds to time from 1 to 65535
    Promises:
    - Pre-loads TMR0H:L to clock out desired period
    - TMR0IF cleared
    - Timer0 enabled
    */
    void TimeXus(u16 u16MicroSeconds)
    {
    T0CON0 &= 0x7f; // Stops the timer
    TMR0H = ((0xffff - u16MicroSeconds) >> 8) & 0xff; // Pre-sets TMR0H registers to the correct value
    TMR0L = (0xffff - u16MicroSeconds) & 0xff; // Pre-sets TMR0L registers to the correct value
    PIR3 &= 0x7f; // Clears the TMR0IF bit
    T0CON0 |= 0x80; // Starts the timer
    } /* end TimeXus () */
    

/*!--------------------------------------------------------------------------------------------------------------------
@fn void UserAppInitialize(void)

@brief
Initializes the application's variables.

Should only be called once in main init section.

Requires:
- NONE

Promises:
- NONE

*/
void UserAppInitialize(void)
{
    LATA = 0x80;
    T0CON0 = 0x90;
    T0CON1 = 0x54;

} /* end UserAppInitialize() */

  
/*!----------------------------------------------------------------------------------------------------------------------
@fn void UserAppRun(void)

@brief Application code that runs once per system loop

Requires:
- 

Promises:
- 

*/
void UserAppRun(void)
{
    static u16 u16Counter = 0x0000; // Static u16 variable counter
    static u8 u8Index = 0x00; // Static u8 variable index
    
    u8 au8Pattern [] = {0x21, 0x12, 0x0c, 0x12}; // u8 variable array to store pattern
    
    u16Counter++; // Increments the counter by 1 each time UseAppRun() is called
    
    
    if(u16Counter == 0x01f4) // Checks if the counter has reached 500
    {
     u16Counter = 0x0000; // Resets the counter to 0
     
     LATA = au8Pattern[u8Index]; // Updates the LEDs by indexing the array to get the current LED state
     
     u8Index++; // Increments the index so the next time the counter hits 500 the next position in the array is indexed
    }
    
    
    if(u8Index == 0x04) // Checks if the index has reached the end of the array
    {
        u8Index = 0x00; // Resets the index to 0
    }
    
} /* end UserAppRun */


/*------------------------------------------------------------------------------------------------------------------*/
/*! @privatesection */                                                                                            
/*--------------------------------------------------------------------------------------------------------------------*/



/*--------------------------------------------------------------------------------------------------------------------*/
/* End of File                                                                                                        */
/*--------------------------------------------------------------------------------------------------------------------*/
